/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventarioferreteria;

/**
 *
 * @author Samsung
 */

public class Producto {
  /**
   * Clase que permite almacenar productos de ferretería con los atributos que se describen a
   * continuación:
   */
  private int clave;//Clave del producto
  private String nombre;//Nombre del producto
  private String descripcion;//Características o particularidades del producto
  private double precioCompra;//Precio unitario del producto, ya sea por pieza o a granel
  private int existencia;//Qué tantas piezas o qué tanto queda del producto
  private String tipoUnidad;//La unidad en la que se mide el producto (m, g, libras, pulgadas, etc.)
  /**
   * Constructor por default
   */
  public Producto(){
    
  }
  
  /**
   * Constructor con atributos. La descripción de cada atribto se encuentra arriba
   * @param clave
   * @param nombre
   * @param descripcion
   * @param precioCompra
   * @param existencia
   * @param tipoUnidad 
   */
  public Producto(int clave, String nombre, String descripcion, double precioCompra, int existencia,
  String tipoUnidad){
    this.clave = clave;
    this.nombre = nombre;
    this.descripcion = descripcion;
    this.precioCompra = precioCompra;
    this.existencia = existencia;
    this.tipoUnidad = tipoUnidad;
  }
  /**
   * Métodos set que establecen los valores de los atributos
   */
  
  public void setClave(int clave){
    this.clave = clave;
  }
  
  public void setNombre(String nombre){
    this.nombre = nombre;
  }
  
  public void setDescripcion(String descripcion){
    this.descripcion = descripcion;
  }
  
  public void setPrecioCompra(double precioCompra){
    this.precioCompra = precioCompra;
  }
  
  public void setExistencia(int existencia){
    this.existencia = existencia;
  }
  
  public void setTipoUnidad(String tipoUnidad){
    this.tipoUnidad = tipoUnidad;
  }
  /**
   * Métodos get que regresan el valor del atributo
   */
  
  public int getClave(){
    return clave;
  }
  
  public String getNombre(){
    return nombre;
  }
  
  public String getDescripcion(){
    return descripcion;
  }
  
  public double getPrecioCompra(){
    return precioCompra;
  }
  
  public int getExistencia(){
    return existencia;
  }
  
  public String getTipoUnidad(){
    return tipoUnidad;
  }
  
}
