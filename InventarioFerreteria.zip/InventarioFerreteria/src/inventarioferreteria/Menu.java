package inventarioferreteria;

/**
 *
 * @author Samsung
 */
public class Menu {
  /**
   * Muestra las opciones que se pueden realizar
   */
  public void menu(){
    System.out.println("Inventario de Ferreteria\n¿Que operación desea realizar?\n"
        + "1. Agregar Producto\t"
        + "2. Eliminar Producto\t"
        + "3. Editar Producto\n"
        + "4. Buscar por Clave\t"
        + "5. Buscar por Nombre\t"
        + "6. Buscar por Descripción\n"
        + "7. Mostrar por Nombre\t"
        + "8. Mostrar por Clave\t"
        + "9. Mostrar el costo del Inventario\n"
        + "10. Salir");
  }
   /**
   * Pide al usuario que ingrese un número desde el teclado
   *
   * @return Opcion introducida por el usuario
   */
  public int leerOpcion() {
    Teclado t = new Teclado();
    System.out.println("Cual es tu opcion?");
    return t.leerEntero();
  }
  /**
   * De acuerdo al valor recibido, el programa realizará la operación indicada
   *
   * @param o: Opción introducida por el usuario para seleccionar qué operación realizar
   */
  public void realizarOperacion(int o){
    Operaciones op = new Operaciones();
    switch(o){
      case 1:
        op.agregarProducto();
        break;
      case 2:
        Teclado t = new Teclado();
        int c;
        System.out.println("Ingresa la clave del producto que deseas eliminar");
        c = t.leerEntero();
        if (op.eliminarArticulo(c)) {
          System.out.println("Producto eliminado del inventario");
        }else{
          System.out.println("Producto no encontrado");
        }
        break;
      case 3:
        Teclado e = new Teclado();
        int id;
        System.out.println("Ingresa la clave del producto que deseas modificar");
        id = e.leerEntero();
        if (op.editarProducto(id)) {
          System.out.println("Producto editado con éxito");
        }else{
          System.out.println("Producto no encontrado");
        }
        break;
      case 4:
        op.buscarClave();
        break;
      case 5:
        op.buscarNombre();
        break;
      case 6:
        op.buscarDescripcion();
        break;
      case 7:
        op.mostrarNombre();
        break;
      case 8:
        op.mostrarClave();
        break;
      case 9:
        op.costoInventario();
        break;
      case 10:
        System.out.println("Adiós vaquero :'v");
        break;
      default:
        System.out.println("Opción inválida");
        break;
    }
  }

}
