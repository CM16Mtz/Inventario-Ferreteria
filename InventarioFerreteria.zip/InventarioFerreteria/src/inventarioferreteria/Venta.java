package inventarioferreteria;

import java.util.Date;

/**
 * @author Samsung
 * @version 1.0
 */
public class Venta {
  
  private int idVenta;
  private Date fechaVenta;
  private Producto p;
  private float cantidad;
  
  public Venta(){
    
  }
  
  public void setIdVenta(int idVenta) {
    this.idVenta = idVenta;
  }
  
  public void setFechaVenta(Date fechaVenta) {
    this.fechaVenta = fechaVenta;
  }
  
  public void setP(Producto p) {
    this.p = p;
  }
  
  public void setCantidad(float cantidad) {
    this.cantidad = cantidad;
  }
  
  public int getIdVenta() {
    return idVenta;
  }
  
  public Date getFechaVenta() {
    return fechaVenta;
  }
  
  public Producto getP() {
    return p;
  }
  
  public float getCantidad() {
    return cantidad;
  }
  
}
