package inventarioferreteria;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author Samsung
 */
public class Operaciones {
  
  private static Producto[] articulos = new Producto[50];
  private static int cantidad;
  
  /**
   * Método que agrega un objeto de tipo producto en el arreglo
   */
  public void agregarProducto(){
    cantidad = 0;
    Teclado t = new Teclado();
    int continuar;
    do{
      Producto p = new Producto();
      int clave = cantidad;
      p.setClave(clave);
      System.out.println("Ingrese el nombre del producto");
      String n = t.leerCadena();
      p.setNombre(n);
      System.out.println("Ingrese su descripcion");
      String d = t.leerCadena();
      p.setDescripcion(d);
      System.out.println("Ingrese su precios de compra");
      double pc = t.leerDouble();
      p.setPrecioCompra(pc);
      System.out.println("Ingrese su existencia");
      int e = t.leerEntero();
      p.setExistencia(e);
      System.out.println("Ingrese su unidad de medida");
      String tu = t.leerCadena();
      p.setTipoUnidad(tu);
      articulos[cantidad] = p;
      System.out.println("¿Deseas añadir otro artículo al inventario?");
      System.out.println("1. Si\t2. Nel perro");
      continuar = t.leerEntero();
      cantidad++;
    }while (continuar == 1);
  }
  /**
   * Método que elimina un producto del arreglo
   */
  public boolean eliminarArticulo(int c){
    boolean e = false;
    for (int i = 0; i < cantidad; i++) {
      if (c == articulos[i].getClave()) {
        if (i == cantidad-1) {
          articulos[i].setClave(0);
          articulos[i].setNombre("");
          articulos[i].setDescripcion("");
          articulos[i].setPrecioCompra(0d);
          articulos[i].setExistencia(0);
          articulos[i].setTipoUnidad("");
        }else{
          for (int j = i+1; j < cantidad; j++) {
            articulos[j-1] = articulos[j];
          }
          articulos[cantidad-1].setClave(0);
          articulos[cantidad-1].setNombre("");
          articulos[cantidad-1].setDescripcion("");
          articulos[cantidad-1].setPrecioCompra(0d);
          articulos[cantidad-1].setExistencia(0);
          articulos[cantidad-1].setTipoUnidad("");
        }
        cantidad--;
        e = true;
      }
    }
    return e;
  }
  /**
   * Metodo que permite editar un atributo de un producto del arreglo
   */
  public boolean editarProducto(int c){
    boolean m = false;
    for (int i = 0; i < 10; i++) {
      if (c == articulos[i].getClave()) {
        Teclado t = new Teclado();
        System.out.println("Ingrese el nuevo nombre del producto");
        String nm = t.leerCadena();
        articulos[i].setNombre(nm);
        System.out.println("Modifique la descripción");
        String nd = t.leerCadena();
        articulos[i].setDescripcion(nd);
        System.out.println("Modifique el precio");
        double npc = t.leerDouble();
        articulos[i].setPrecioCompra(npc);
        System.out.println("Modifique la existencia");
        int ne = t.leerEntero();
        articulos[i].setExistencia(ne);
        System.out.println("Modifique su unidad de medida");
        String ntu = t.leerCadena();
        articulos[i].setTipoUnidad(ntu);
        m = true;
      }
    }
    return m;
  }
  /**
   * Método que permite buscar un producto por clave
   */
  public void buscarClave(){
    Teclado t = new Teclado();
    System.out.println("Ingrese la clave del producto que deseas encontrar");
    int c = t.leerEntero();
    for (int i = 0; i < cantidad; i++) {
      if (c == articulos[i].getClave()) {
        System.out.println("Clave produ:\t"+articulos[i].getClave());
        System.out.println("Nombre prod:\t"+articulos[i].getNombre());
        System.out.println("Descripcion:\t"+articulos[i].getDescripcion());
        System.out.println("Precio comp:\t"+articulos[i].getPrecioCompra());
        System.out.println("Existencia :\t"+articulos[i].getExistencia());
        System.out.println("Se mide en :\t"+articulos[i].getTipoUnidad());
      }
    }
  }
  /**
   * Método que permite buscar un producto por nombre
   */
  public void buscarNombre(){
    Teclado t = new Teclado();
    System.out.println("Ingrese el nombre del producto que deseas encontrar");
    String n = t.leerSiguienteCadena();
    for (int i = 0; i < cantidad; i++) {
      if (n == articulos[i].getNombre()) {
        System.out.println("Clave produ:\t"+articulos[i].getClave());
        System.out.println("Nombre prod:\t"+articulos[i].getNombre());
        System.out.println("Descripcion:\t"+articulos[i].getDescripcion());
        System.out.println("Precio comp:\t"+articulos[i].getPrecioCompra());
        System.out.println("Existencia :\t"+articulos[i].getExistencia());
        System.out.println("Se mide en :\t"+articulos[i].getTipoUnidad());
      }
    }
  }
  /**
   * Método que permite buscar un producto por descripcion
   */
  public void buscarDescripcion(){
    Teclado t = new Teclado();
    System.out.println("Ingrese la descripcion del/los producto(s) que deseas encontrar");
    String d = t.leerSiguienteCadena();
    for (int i = 0; i < cantidad; i++) {
      if (d == articulos[i].getNombre()) {
        System.out.println("Clave produ:\t"+articulos[i].getClave());
        System.out.println("Nombre prod:\t"+articulos[i].getNombre());
        System.out.println("Descripcion:\t"+articulos[i].getDescripcion());
        System.out.println("Precio comp:\t"+articulos[i].getPrecioCompra());
        System.out.println("Existencia :\t"+articulos[i].getExistencia());
        System.out.println("Se mide en :\t"+articulos[i].getTipoUnidad());
      }
    }
  }
  /**
   * Método que imprime una lista con los nombres de los artículos
   */
  public void mostrarNombre(){
    System.out.println("Estos son los nombres de los productos");
    for (int i = 0; i < cantidad; i++) {
      System.out.println("Nombre:\t"+articulos[i].getNombre());
    }
  }
  /**
   * Método que imprime una lista con las claves y nombres de los artículos
   */
  public void mostrarClave(){
    System.out.println("Estos son las claves de los productos con sus nombres");
    for (int i = 0; i < cantidad; i++) {
      System.out.println("Clave:\t"+articulos[i].getClave()+" ("+articulos[i].getNombre()+")");
    }
  }
  /**
   * Método que calcula la sumatoria de los precios unitarios de los artículos del arreglo
   */
  public void costoInventario(){
    double sumatoria = 0;
    for (int i = 0; i < cantidad; i++) {
      sumatoria += articulos[i].getPrecioCompra();
    }
    System.out.println("El costo total del inventario es: "+sumatoria);
  }
  /**
   * Método que imprime los datos de los productos del arreglo
   */
  public void mostrarArticulos(){
    System.out.println("Estos son los productos del inventario");
    System.out.println("Clave\tNombre\tDescripcion\tPrecio de Compra\tExistencia\t"
        + "Unidad de Medida");
    for (int i = 0; i < cantidad; i++) {
      System.out.println(articulos[i].getClave() + "\t" + articulos[i].getNombre() + "\t"
        + articulos[i].getDescripcion() + "\t" + articulos[i].getPrecioCompra() + "\t"
        + articulos[i].getExistencia() + "\t" + articulos[i].getTipoUnidad());
    }
  }
      
}
