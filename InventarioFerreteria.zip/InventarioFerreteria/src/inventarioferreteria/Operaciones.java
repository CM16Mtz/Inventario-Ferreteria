package inventarioferreteria;

/**
 * @author Samsung
 * @version 1.0
 */
public class Operaciones {
  
  private static Producto[] articulos = new Producto[50];    //Arreglo que guarda los artículos
  private static int cantidad;    //Representa el rango del arreglo anterior
  
  /**
   * Método que agrega un objeto de tipo producto en el arreglo
   */
  public void agregarProducto(){
    cantidad = 0;    //El primer producto estará en esa posición
    Teclado t = new Teclado();    //Instancia para que el usuario ingrese los datos
    int continuar;    //Entero que determinará si se agregará otro producto o no
    do{
      Producto p = new Producto();    //Se crea un nuevo producto
      int clave = cantidad;
      p.setClave(clave);
      System.out.println("Ingrese el nombre del producto");
      String n = t.leerSiguienteCadena();
      p.setNombre(n);
      System.out.println("Ingrese su descripcion");
      String d = t.leerSiguienteCadena();
      p.setDescripcion(d);
      System.out.println("Ingrese su precios de compra");
      double pc = t.leerDouble();
      p.setPrecioCompra(pc);
      System.out.println("Ingrese su existencia");
      int e = t.leerEntero();
      p.setExistencia(e);
      System.out.println("Ingrese su unidad de medida");
      String tu = t.leerSiguienteCadena();
      p.setTipoUnidad(tu);
      articulos[cantidad] = p;
      System.out.println("¿Deseas añadir otro artículo al inventario?");
      System.out.println("1. Si\t2. Nel perro");
      continuar = t.leerEntero();
      cantidad++;    //Una vez ingresado el producto, 'cantidad' incrementa 1
    }while (continuar == 1);
  }
  /**
   * Método que elimina un producto del arreglo
   * @param c Clave del producto que se desea eliminar
   */
  public void eliminarArticulo(int c){
    boolean e = false;    //Bandera que determinará si el artículo se eliminó o no
    for (int i = 0; i < cantidad; i++) {    //Buscará desde el inicio hasta el final
      if (c == articulos[i].getClave()) {    //la clave, si existe
        if (i == cantidad-1) {    //En este caso, el último artículo ingresado se destruye
          articulos[i].setClave(0);
          articulos[i].setNombre("");
          articulos[i].setDescripcion("");
          articulos[i].setPrecioCompra(0d);
          articulos[i].setExistencia(0);
          articulos[i].setTipoUnidad("");
        }else{    //En este caso, se recorrerán los artículos 1 posición menos,
          for (int j = i+1; j < cantidad; j++) {    //y se destruye el último
            articulos[j-1].setClave(j-1);
            articulos[j-1].setNombre(articulos[j].getNombre());
            articulos[j-1].setDescripcion(articulos[j].getDescripcion());
            articulos[j-1].setPrecioCompra(articulos[j].getPrecioCompra());
            articulos[j-1].setExistencia(articulos[j].getExistencia());
            articulos[j-1].setTipoUnidad(articulos[j].getTipoUnidad());
          }
          articulos[cantidad-1].setClave(0);
          articulos[cantidad-1].setNombre("");
          articulos[cantidad-1].setDescripcion("");
          articulos[cantidad-1].setPrecioCompra(0d);
          articulos[cantidad-1].setExistencia(0);
          articulos[cantidad-1].setTipoUnidad("");
        }
        cantidad--;    //Se reduce el rango del arreglo
        e = true;    //Indica que la eliminación se completó
      }
    }
    if (e) {    //Mensajes que se imprimirán dependiendo del valor de 'e'
      System.out.println("Artículo eliminado con éxito");
    }else{
      System.out.println("Artículo no encontrado");
    }
  }
  /**
   * Metodo que permite editar un atributo de un producto del arreglo
   * @param id Clave del producto a editar
   */
  public void editarProducto(int id){
    boolean m = false;    //Bandera que indicará si el artículo se modificó o no
    for (int i = 0; i < cantidad; i++) {    //Buscará la clave del artículo desde el inicio
      if (id == articulos[i].getClave()) {    //Si se encontró, se procederá a lo siguiente
        Producto p2 = new Producto();
        Teclado t = new Teclado();
        int cla = i;
        p2.setClave(cla);
        System.out.println("Ingrese el nuevo nombre del producto");
        String nm = t.leerSiguienteCadena();
        p2.setNombre(nm);
        System.out.println("Modifique la descripción");
        String nd = t.leerSiguienteCadena();
        p2.setDescripcion(nd);
        System.out.println("Modifique el precio");
        double npc = t.leerDouble();
        p2.setPrecioCompra(npc);
        System.out.println("Modifique la existencia");
        int ne = t.leerEntero();
        p2.setExistencia(ne);
        System.out.println("Modifique su unidad de medida");
        String ntu = t.leerSiguienteCadena();
        p2.setTipoUnidad(ntu);
        articulos[i] = p2;
        m = true;    //Indica que el artículo se modificó
      }
    }
    if (!m) {    //Si 'm' no cambió su valor inicial, se imprimirá lo siguiente
      System.out.println("Artículo no encontrado");
    }
  }
  /**
   * Método que permite buscar un producto por clave
   */
  public void buscarClave(){
    Teclado t = new Teclado();
    boolean b = false;    //Bandera que indica si el producto se encontró o no
    System.out.println("Ingrese la clave del producto que deseas encontrar");
    int c = t.leerEntero();    //Se lee el entero
    for (int i = 0; i < cantidad; i++) {    //Si el artículo es encontrado,
      if (c == articulos[i].getClave()) {    //se imprimirá lo siguiente
        System.out.println("Clave produ:\t"+articulos[i].getClave());
        System.out.println("Nombre prod:\t"+articulos[i].getNombre());
        System.out.println("Descripcion:\t"+articulos[i].getDescripcion());
        System.out.println("Precio comp:\t"+articulos[i].getPrecioCompra());
        System.out.println("Existencia :\t"+articulos[i].getExistencia());
        System.out.println("Se mide en :\t"+articulos[i].getTipoUnidad());
        b = true;    //Indica que el producto existe
      }
    }
    if (!b) {    //Si el producto no se encontró, imprimir
      System.out.println("Producto no encontrado");
    }
  }
  /**
   * Método que permite buscar un producto por nombre
   */
  public void buscarNombre(){
    Teclado t = new Teclado();
    boolean b = false;
    System.out.println("Ingrese el nombre del producto que deseas encontrar");
    String n = t.leerSiguienteCadena();
    for (int i = 0; i < cantidad; i++) {
      if ((articulos[i].getNombre()).equals(n)) {
        System.out.println("Clave produ:\t"+articulos[i].getClave());
        System.out.println("Nombre prod:\t"+articulos[i].getNombre());
        System.out.println("Descripcion:\t"+articulos[i].getDescripcion());
        System.out.println("Precio comp:\t"+articulos[i].getPrecioCompra());
        System.out.println("Existencia :\t"+articulos[i].getExistencia());
        System.out.println("Se mide en :\t"+articulos[i].getTipoUnidad());
        b = true;
      }
    }
    if (!b) {
      System.out.println("Producto no encontrado");
    }
  }
  /**
   * Método que permite buscar un producto por descripcion
   */
  public void buscarDescripcion(){
    Teclado t = new Teclado();
    boolean b = false;
    System.out.println("Ingrese la descripcion del/los producto(s) que deseas encontrar");
    String d = t.leerSiguienteCadena();
    for (int i = 0; i < cantidad; i++) {
      if ((articulos[i].getDescripcion()).equals(d)) {
        System.out.println("Clave produ:\t"+articulos[i].getClave());
        System.out.println("Nombre prod:\t"+articulos[i].getNombre());
        System.out.println("Descripcion:\t"+articulos[i].getDescripcion());
        System.out.println("Precio comp:\t"+articulos[i].getPrecioCompra());
        System.out.println("Existencia :\t"+articulos[i].getExistencia());
        System.out.println("Se mide en :\t"+articulos[i].getTipoUnidad());
      }
    }
    if (!b) {
      System.out.println("Producto no encontrado");
    }
  }
  /**
   * Método que imprime una lista con los nombres de los artículos
   */
  public void mostrarNombre(){
    if (cantidad < 0) {
      System.out.println("Lista vacía");
    }else{
      System.out.println("Estos son los nombres de los productos");
      for (int i = 0; i < cantidad; i++) {
        System.out.println("Nombre:\t"+articulos[i].getNombre());
      }
    }
  }
  /**
   * Método que imprime una lista con las claves y nombres de los artículos
   */
  public void mostrarClave(){
    if (cantidad < 0) {
      System.out.println("Lista vacía");
    }else{
    System.out.println("Estos son las claves de los productos con sus nombres");
    for (int i = 0; i < cantidad; i++) {
      System.out.println("Clave:\t"+articulos[i].getClave()+" ("+articulos[i].getNombre()+")");
      }
    }
  }
  /**
   * Método que calcula la sumatoria de los precios unitarios de los artículos del arreglo
   */
  public void costoInventario(){
    double sumatoria = 0;
    System.out.println("Clave\t Nombre\t Precio de compra");
    for (int i = 0; i < cantidad; i++) {
      System.out.println(articulos[i].getClave()+articulos[i].getNombre()
          +articulos[i].getPrecioCompra());
      sumatoria += articulos[i].getPrecioCompra();
    }
    System.out.println("El costo total del inventario es: "+sumatoria);
  }
  /**
   * Método que calcula las ganancias con respecto a las ventas generadas
   */
  public void ganancias(){
    
  }
  /**
   * Método que imprime qué ventas se efectuaron en tal día
   */
  public void fechaVentas(){
    
  }
  
}
