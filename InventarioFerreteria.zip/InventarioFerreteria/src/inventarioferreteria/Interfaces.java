package inventarioferreteria;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * @author Samsung
 * @version 1.0
 */

public class Interfaces extends Application {    //Heredará un método abstracto de 'Application'
  
  private static Producto[] articulos = new Producto[10];
  private static int cantidad;
  
  /**
   * Menú para que el usuario inicie sesión
   * @param primaryStage Atributo stage que conforma la ventana de la aplicación
   * @throws Exception 
   */
  @Override
  public void start(Stage primaryStage) throws Exception {
    primaryStage.setTitle("Iniciar sesión");    //Se le da título a la ventana
    StackPane root = new StackPane();    //Se establece el trazado de la ventana
    Label l = new Label("Ingrese sus datos");    //Se declara el título en el Scene
    l.setFont(new Font("Arial", 16));    //Se establece la fuente y tamaño del Label
    TextField tf = new TextField();    //Se declara el TextField donde se ingresará el usuario
    tf.setPromptText("Usuario");    //El TextField inicia con el texto "Usuario"
    PasswordField pf = new PasswordField();    //Se declara un TextField especial para contraseña
    pf.setPromptText("Contraseña");    //El PasswordField inicia con el texto "Contraseña"
    Button button = new Button();    //Se declara el botón de la ventana
    button.setText("Acceder");    //Se le da texto al botón
    final Text advertencia = new Text();    //Advertencia de fallo al iniciar sesión
    VBox v = new VBox(16);    //Caja vertical que almacenará elementos JavaFX
    v.setAlignment(Pos.CENTER);    //Se alínea el VBox al centro de la ventana
    v.setPadding(new Insets(16, 16, 16, 16));
    //Se establece la distancia de los elementos y los bordes de la ventana
    v.getChildren().addAll(l, tf, pf, button, advertencia);    //Se añaden los elementos al VBox
    button.setOnAction(new EventHandler<ActionEvent>(){    //Evento a efectuarse
      @Override
      public void handle(ActionEvent t) {    //Cuando el usuario aplaste el botón...
        if (tf.getText().equals("JatnielMar") && pf.getText().equals("aquituveyo")) {
          //Si los datos ingresados coinciden con los correctos, entonces se ejecuta el menu         
          menu();
          advertencia.setText(null);
        }else{
          //Si los datos ingresados no coinciden con los correctos, entonces
          advertencia.setFill(Color.FIREBRICK);
          advertencia.setText("Fallo al iniciar sesión");
        }
      }      
    });
    root.getChildren().add(v);    //Se añade el botón al objeto 'StackPane'
    Scene scene = new Scene(root);    //Se establece la escena de la ventana
    primaryStage.setScene(scene);    //Se añade la escena al objeto 'Stage'
    primaryStage.setResizable(false);    //Con esto se evitará la redimensión de la ventana
    primaryStage.show();    //Imprime el objeto 'Stage'
  }
  /**
   * Menú que incluye las funciones principales del inventario
   */
  public void menu() {
    Stage secondaryStage = new Stage();
    secondaryStage.setTitle("Menú principal");    //Nombre de la ventana
    Label l = new Label("¿Qué desea hacer?");    //Encabezado del Scene
    l.setFont(new Font("Arial", 16));    //Se establece la fuente del Label
    Button b1 = new Button();    //Botón para acceder a la función 'Agregar Producto'
    b1.setText("Agregar Producto");    //Se le da texto al botón
    b1.setOnAction(new EventHandler<ActionEvent>() {
      @Override    //Cuando presione el botón, se ejecutará el menú 'agregarProducto'
      public void handle(ActionEvent t) {
        agregarProducto();
      }
    });
    Button b2 = new Button();    //Botón para acceder a la función 'Eliminar Producto'
    b2.setText("Eliminar Producto");    //Se le da texto al botón
    b2.setOnAction(new EventHandler<ActionEvent>() {
      @Override    //Cuando presione el botón, se ejecutará el menú 'eliminarProducto'
      public void handle(ActionEvent t) {
        eliminarProducto();
      }
    });
    Button b3 = new Button();    //Botón para acceder a la función 'Editar Producto'
    b3.setText("Editar Producto");    //Se le da texto al botón
    b3.setOnAction(new EventHandler<ActionEvent>() {
      @Override    //Cuando presione el botón, se ejecutará el menú 'editarProducto'
      public void handle(ActionEvent t) {
        editarProducto();
      }
    });
    Button b4 = new Button();    //Botón para acceder a la función 'Buscar por clave'
    b4.setText("Buscar por clave");    //Se le da texto al botón
    b4.setOnAction(new EventHandler<ActionEvent>() {
      @Override    //Cuando presione el botón, se ejecutará el menú 'buscarClave'
      public void handle(ActionEvent t) {
        buscarClave();
      }
    });
    Button b5 = new Button();    //Botón para acceder a la función 'Buscar por nombre'
    b5.setText("Buscar por nombre");    //Se le da texto al botón
    b5.setOnAction(new EventHandler<ActionEvent>() {
      @Override    //Cuando presione el botón, se ejecutará el menú 'buscarNombre'
      public void handle(ActionEvent t) {
        buscarNombre();
      }
    });
    Button b6 = new Button();    //Botón para acceder a la función 'Buscar por descripción'
    b6.setText("Buscar por descripción");    //Se le da texto al botón
    b6.setOnAction(new EventHandler<ActionEvent>() {
      @Override    //Cuando presione el botón, se ejecutará el menú 'buscarDescripcion'
      public void handle(ActionEvent t) {
        buscarDescripcion();
      }
    });
    Button b7 = new Button();    //Botón para acceder a la función 'Mostrar por nombre'
    b7.setText("Mostrar por nombre");    //Se le da texto al botón
    b7.setOnAction(new EventHandler<ActionEvent>() {
      @Override    //Cuando presione el botón, se ejecutará el menú 'mostrarNombre'
      public void handle(ActionEvent t) {
        mostrarNombre();
      }
    });
    Button b8 = new Button();    //Botón para acceder a la función 'Mostrar por clave'
    b8.setText("Mostrar por clave");    //Se le da texto al botón
    b8.setOnAction(new EventHandler<ActionEvent>() {
      @Override    //Cuando presione el botón, se ejecutará el menú 'mostrarClave'
      public void handle(ActionEvent t) {
        mostrarClave();
      }
    });
    Button b9 = new Button();    //Botón para acceder a la función 'Mostrar el costo del inventario'
    b9.setText("Mostrar el costo del inventario");    //Se le da texto al botón
    b9.setOnAction(new EventHandler<ActionEvent>() {
      @Override    //Cuando presione el botón, se ejecutará el menú 'costo'
      public void handle(ActionEvent t) {
        costo();
      }
    });
    VBox v = new VBox(16);    //Caja vertical que contendrá los botones y el label
    v.setAlignment(Pos.CENTER);    //Se alinea el VBox al centro de la ventana
    //Se establece el espaciado entre los elementos y los bordes de la ventana
    v.setPadding(new Insets(16, 16, 16, 16));
    v.getChildren().addAll(l, b1, b2, b3, b4, b5, b6, b7, b8, b9);    //Añade los elementos
    StackPane sp = new StackPane();
    sp.getChildren().add(v);
    Scene s = new Scene(sp, Color.CYAN);
    secondaryStage.setScene(s);
    secondaryStage.setResizable(false);
    secondaryStage.show();
  }
  
  public void agregarProducto() {
    Stage ap = new Stage();
    ap.setTitle("Agregar Producto");
    //Instrucción de la ventana
    cantidad = 0;    //El primer producto estará en esa posición
    Label l = new Label("Favor de llenar los siguientes campos para dar de alta el nuevo producto");
    l.setFont(new Font("Arial", 16));
    //Campos en donde el usuario deberá ingresar los datos del producto a agregar
    TextField nombre = new TextField();    //TextField donde se ingresará el nombre del producto
    nombre.setPromptText("Nombre del producto");
    TextField descripcion = new TextField();    //TextField donde se ingresará la descripción
    descripcion.setPromptText("Descripción");
    TextField precio = new TextField();    //TextField donde se ingresará el precio
    precio.setPromptText("Precio de compra");
    TextField existencia = new TextField();    //TextField donde se ingresará la existencia
    existencia.setPromptText("Existencia");
    TextField um = new TextField();    //TextField donde se ingresará la unidad de medida
    um.setPromptText("Unidad de Medida");
    //Botón que servirá para agregar el producto
    Button alta = new Button();    //Botón que registrará el producto
    alta.setText("Agregar");    //Texto del botón
    final Text agregado = new Text();    //Leyenda que dirá mensajes al hacer click en 'Agregar'
    alta.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent t) {
        if (!nombre.getText().isEmpty() && !descripcion.getText().isEmpty() && 
            !precio.getText().isEmpty() && !existencia.getText().isEmpty() && 
            !um.getText().isEmpty()) {
          //Si no quedan campos vacíos
          Producto p = new Producto();    //Se instancia un nuevo producto
          //Se añaden los datos al objeto
          int clave = cantidad;
          p.setClave(clave);
          String n = nombre.getText();
          p.setNombre(n);
          String d = descripcion.getText();
          p.setDescripcion(d);
          double pr = Double.parseDouble(precio.getText());
          p.setPrecioCompra(pr);
          int e = Integer.parseInt(existencia.getText());
          p.setExistencia(e);
          String u = um.getText();
          p.setTipoUnidad(u);
          articulos[cantidad] = p;    //Se guarda el producto en el arreglo
          agregado.setFill(Color.GREEN);    //El sistema despliega el mensaje de abajo en verde
          agregado.setText("Artículo agregado al inventario");
          cantidad++;    //El rango del arreglo incrementa 1
        }else{
          //Si quedan campos vacíos
          agregado.setFill(Color.FIREBRICK);    //El sistema despliega el mensaje de abajo en rojo
          agregado.setText("Aún quedan campos vacíos");
        }
      }      
    });
    VBox v = new VBox(16);    //Caja que agrupará los elementos
    v.setAlignment(Pos.CENTER);    //Se alínea la caja al centro
    v.setPadding(new Insets(16, 16, 16, 16));    //Se dejarán espacios entre los elementos
    v.getChildren().addAll(l, nombre, descripcion, precio, existencia, um, alta, agregado);
    StackPane sp = new StackPane();
    sp.getChildren().add(v);    //Se añade la caja vertical al StackPane
    Scene s = new Scene(sp);    //Se añade el StackPane al Scene
    ap.setScene(s);    //Se establece el Scene del Stage
    ap.setResizable(false);    //Restringe la redimensión de la ventana
    ap.show();    //Imprime la ventana
  }
  
  public void eliminarProducto() {
    Stage ep = new Stage();    //Se instancia una ventana
    ep.setTitle("Eliminar Producto");    //Se le da título a la ventana
    Label l = new Label("Ingrese la clave del producto que desea eliminar");
    l.setFont(new Font("Arial", 16));
    TextField clave = new TextField();    //Campo donde se ingresará la clave
    clave.setPromptText("Clave");    //Texto por defecto de la clave
    HBox h = new HBox(8);    //Caja horizontal que agrupará el Label y el TextField
    h.setAlignment(Pos.CENTER);    //Se alinea la caja al centro de la ventana
    h.getChildren().addAll(l, clave);    //Se añaden los elementos a la caja
    Button baja = new Button();    //Botón que efectuará la baja del producto
    baja.setText("Eliminar");    //Texto del botón
    final Text eliminado = new Text();    //Leyenda que aparece tras presionar 'Eliminar'
    baja.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent t) {
        boolean e = false;    //boolean que determinará la confirmación de la eliminación
        if (!clave.getText().isEmpty()) {
          //Si el campo no está vacío
          for (int i = 0; i < cantidad; i++) {    //Buscará la clave a lo largo del arreglo
            if (Integer.parseInt(clave.getText()) == articulos[i].getClave()) {
              if (i == cantidad-1) {    //En caso de que el producto sea el último del arreglo
                //Se destruye el Producto
                articulos[i].setClave(0);
                articulos[i].setNombre("");
                articulos[i].setDescripcion("");
                articulos[i].setPrecioCompra(0d);
                articulos[i].setExistencia(0);
                articulos[i].setTipoUnidad("");
              }else{    //En caso de que el producto esté antes del final del arreglo
                for (int j = i+1; j < cantidad; j++) {
                  //Los productos recorren un índice menos, sobreescribiendo el que será destruido
                  articulos[j-1].setClave(j-1);
                  articulos[j-1].setNombre(articulos[j].getNombre());
                  articulos[j-1].setDescripcion(articulos[j].getDescripcion());
                  articulos[j-1].setPrecioCompra(articulos[j].getPrecioCompra());
                  articulos[j-1].setExistencia(articulos[j].getExistencia());
                  articulos[j-1].setTipoUnidad(articulos[i].getTipoUnidad());
                }
                //Se destruye el último producto
                articulos[cantidad-1].setClave(0);
                articulos[cantidad-1].setNombre("");
                articulos[cantidad-1].setDescripcion("");
                articulos[cantidad-1].setPrecioCompra(0d);
                articulos[cantidad-1].setExistencia(0);
                articulos[cantidad-1].setTipoUnidad("");
              }
              cantidad--;    //El tamaño del arreglo se reduce 1
              e = true;    //Se confirma la eliminación del producto
            }
          }
          if (e) {
            //Si el producto se eliminó
            eliminado.setFill(Color.GREEN);
            eliminado.setText("Artículo eliminado del inventario");
          }else{
            //Si no encontró la clave del producto
            eliminado.setFill(Color.FIREBRICK);
            eliminado.setText("Artículo no encontrado");
          }
        }else{
          //Si el campo está vacío
          eliminado.setFill(Color.VIOLET);
          eliminado.setText("No puedes dejar el campo vacío");
        }
      }
    });
    VBox v = new VBox(16);    //Caja vertical que agrupará los elementos
    v.setAlignment(Pos.CENTER);    //Se alinea la caja al centro de la ventana
    v.setPadding(new Insets(16, 16, 16, 16));    //Se distancia la caja de los bordes de la ventana
    v.getChildren().addAll(h, baja, eliminado);    //Se añaden los elementos a la caja
    StackPane sp = new StackPane();
    sp.getChildren().add(v);    //Se añade la caja vertical al StackPane
    Scene s = new Scene(sp);
    ep.setScene(s);
    ep.setResizable(false);    //Impide la redimensión de la ventana
    ep.show();    //Imnprime la ventana
  }
  
  public void editarProducto() {
    Stage ep = new Stage();    //Se instancia una nueva ventana
    ep.setTitle("Editar Producto");    //Título de la ventana
    Label l = new Label("Ingresa la clave del producto que deseas modificar");
    l.setFont(new Font("Arial", 16));
    TextField clave = new TextField();    //TextField donde se ingresará la clave del producto
    clave.setPromptText("Clave");
    HBox h = new HBox(8);    //Caja horizontal
    h.setAlignment(Pos.CENTER);    //Se alinea la caja al centro de la ventana
    h.getChildren().addAll(l, clave);    //Se añaden los elementos a la caja
    Button editar = new Button();    //Botón que ejecutará la modificación del artículo
    editar.setText("Modificar");
    final Text nel = new Text();
    editar.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent t) {
        boolean m = false;
        if (!clave.getText().isEmpty()) {
          //Si el campo no está vacío
          for (int i = 0; i < cantidad; i++) {
            if (Integer.parseInt(clave.getText()) == articulos[i].getClave()) {
              modificar(i);    //Se llama al menú 'modificar'
              m = true;    //Se confirma la actualización
            }
          }
          if (!m) {
            nel.setFill(Color.FIREBRICK);
            nel.setText("Producto no encontrado");
          }
        }else{
          //Si el campo está vacío
          nel.setFill(Color.VIOLET);
          nel.setText("No puedes dejar el campo vacío");
        }
      }
    });
    VBox v = new VBox(16);
    v.setAlignment(Pos.CENTER);
    v.setPadding(new Insets(16, 16, 16, 16));
    v.getChildren().addAll(h, editar, nel);
    StackPane sp = new StackPane();
    sp.getChildren().add(v);
    Scene s = new Scene(sp);
    ep.setScene(s);
    ep.setResizable(false);
    ep.show();
  }
  
  public void modificar(int i) {
    Stage m = new Stage();
    m.setTitle("Editar Producto");
    //Instrucción de la ventana
    Label l = new Label("Favor de llenar los siguientes campos para modificar el producto");
    l.setFont(new Font("Arial", 16));
    //Campos en donde el usuario deberá ingresar los datos del producto a agregar
    TextField nombre = new TextField();    //TextField donde se ingresará el nombre del producto
    nombre.setText(articulos[i].getNombre());
    TextField descripcion = new TextField();    //TextField donde se ingresará la descripción
    descripcion.setText(articulos[i].getDescripcion());
    TextField precio = new TextField();    //TextField donde se ingresará el precio
    precio.setText(Double.toString(articulos[i].getPrecioCompra()));
    TextField existencia = new TextField();    //TextField donde se ingresará la existencia
    existencia.setText(Integer.toString(articulos[i].getExistencia()));
    TextField um = new TextField();    //TextField donde se ingresará la unidad de medida
    um.setText(articulos[i].getTipoUnidad());
    //Botón que servirá para agregar el producto
    Button actualizar = new Button();    //Botón que registrará el producto
    actualizar.setText("Actualizar");    //Texto del botón
    final Text actualizado = new Text();
    actualizar.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent t) {
        if (!nombre.getText().isEmpty() && !descripcion.getText().isEmpty() && 
            !precio.getText().isEmpty() && !existencia.getText().isEmpty() && 
            !um.getText().isEmpty()) {
          //Si no quedan campos vacíos
          Producto p2 = new Producto();    //Se instancia un nuevo producto
          //Se añaden los datos al objeto
          int clave = i;
          p2.setClave(clave);
          String n = nombre.getText();
          p2.setNombre(n);
          String d = descripcion.getText();
          p2.setDescripcion(d);
          double pr = Double.parseDouble(precio.getText());
          p2.setPrecioCompra(pr);
          int e = Integer.parseInt(existencia.getText());
          p2.setExistencia(e);
          String u = um.getText();
          p2.setTipoUnidad(u);
          articulos[i] = p2;    //Se guardan las actualizaciones del producto
          actualizado.setFill(Color.GREEN);
          actualizado.setText("Artículo actualizado");
        }else{
          //Si quedan campos vacíos
          actualizado.setFill(Color.FIREBRICK);
          actualizado.setText("Aún quedan campos vacíos");
        }
      }      
    });
    VBox v = new VBox(16);    //Caja que agrupará los elementos
    v.setAlignment(Pos.CENTER);    //Se alínea la caja al centro
    v.setPadding(new Insets(16, 16, 16, 16));    //Se dejarán espacios entre los elementos
    v.getChildren().addAll(l, nombre, descripcion, precio, existencia, um, actualizar, actualizado);
    StackPane sp = new StackPane();
    sp.getChildren().add(v);    //Se añade la caja vertical al StackPane
    Scene s = new Scene(sp);    //Se añade el StackPane al Scene
    m.setScene(s);    //Se establece el Scene del Stage
    m.setResizable(false);    //Restringe la redimensión de la ventana
    m.show();    //Imprime la ventana    
  }
  
  public void datos(Producto p) {
    Stage d = new Stage();
    d.setTitle("Producto encontrado");
    TableView<Producto> tv = new TableView<>();
    ObservableList<Producto> ol = FXCollections.observableArrayList(p);
    Scene s = new Scene(new Group());
    Label info = new Label("Datos del producto encontrado");
    tv.setEditable(true);
    TableColumn cc = new TableColumn("Clave");
    cc.setCellValueFactory(new PropertyValueFactory<>("clave"));
    TableColumn cn = new TableColumn("Nombre");
    cn.setCellValueFactory(new PropertyValueFactory<>("nombre"));
    TableColumn cd = new TableColumn("Descripción");
    cd.setCellValueFactory(new PropertyValueFactory<>("descripcion"));
    TableColumn cp = new TableColumn("Precio");
    cp.setCellValueFactory(new PropertyValueFactory<>("precioCompra"));
    TableColumn ce = new TableColumn("Existencia");
    ce.setCellValueFactory(new PropertyValueFactory<>("existencia"));
    TableColumn cu = new TableColumn("Unidad");
    cu.setCellValueFactory(new PropertyValueFactory<>("tipoUnidad"));
    tv.setItems(ol);
    tv.getColumns().addAll(cc, cn, cd, cp, ce, cu);
    VBox vb = new VBox(8);
    vb.setAlignment(Pos.CENTER);
    vb.setPadding(new Insets(16, 8, 8, 16));
    vb.getChildren().addAll(info, tv);
    ((Group) s.getRoot()).getChildren().addAll(vb);
    d.setScene(s);
    d.setResizable(false);
    d.show();
  }
  
  public void buscarClave() {
    Stage bc = new Stage();
    bc.setTitle("Buscar Producto por Clave");
    Label l = new Label("Ingresa la clave del producto a buscar");
    l.setFont(new Font("Arial", 16));
    TextField clave = new TextField();
    clave.setPromptText("Clave");
    HBox h = new HBox(8);
    h.setAlignment(Pos.CENTER);
    h.getChildren().addAll(l, clave);
    Button buscar = new Button();
    buscar.setText("Buscar");
    final Text buscado = new Text();
    buscar.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent t) {
        boolean enc = false;
        if (!clave.getText().isEmpty()) {
          for (int i = 0; i < cantidad; i++) {
            if (Integer.parseInt(clave.getText()) == articulos[i].getClave()) {
              datos(articulos[i]);
              enc = true;
            }
          }
          if (!enc) {
            buscado.setFill(Color.BLUEVIOLET);
            buscado.setText("Producto no encontrado");
          }
        }else{
          buscado.setFill(Color.VIOLET);
          buscado.setText("No puedes dejar el campo vacío");
        }
      }
    });
    VBox v = new VBox(16);
    v.setAlignment(Pos.CENTER);
    v.setPadding(new Insets(16, 16, 16, 16));
    v.getChildren().addAll(h, buscar, buscado);
    StackPane sp = new StackPane();
    sp.getChildren().add(v);
    Scene s = new Scene(sp);
    bc.setScene(s);
    bc.setResizable(false);
    bc.show();
  }
  
  public void buscarNombre() {
    Stage bn = new Stage();
    bn.setTitle("Buscar Producto por Nombre");
    Label l = new Label("Ingresa el nombre del producto a buscar");
    l.setFont(new Font("Arial", 16));
    TextField nombre = new TextField();
    nombre.setPromptText("Nombre");
    HBox h = new HBox(8);
    h.setAlignment(Pos.CENTER);
    h.getChildren().addAll(l, nombre);
    Button buscar = new Button();
    buscar.setText("Buscar");
    final Text buscado = new Text();
    buscar.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent t) {
        boolean enc = false;
        if (!nombre.getText().isEmpty()) {
          for (int i = 0; i < cantidad; i++) {
            if (nombre.getText().equals(articulos[i].getNombre())) {
              datos(articulos[i]);
              enc = true;
            }
          }
          if (!enc) {
            buscado.setFill(Color.BLUEVIOLET);
            buscado.setText("Producto no encontrado");
          }
        }else{
          buscado.setFill(Color.VIOLET);
          buscado.setText("No puedes dejar el campo vacío");
        }
      }
    });
    VBox v = new VBox(16);
    v.setAlignment(Pos.CENTER);
    v.setPadding(new Insets(16, 16, 16, 16));
    v.getChildren().addAll(h, buscar, buscado);
    StackPane sp = new StackPane();
    sp.getChildren().add(v);
    Scene s = new Scene(sp);
    bn.setScene(s);
    bn.setResizable(false);
    bn.show();    
  }
  
  public void buscarDescripcion() {
    Stage bd = new Stage();
    bd.setTitle("Buscar Producto por Descripción");
    Label l = new Label("Ingresa la descripción del producto a buscar");
    l.setFont(new Font("Arial", 16));
    TextField descripcion = new TextField();
    descripcion.setPromptText("Descripción");
    HBox h = new HBox(8);
    h.setAlignment(Pos.CENTER);
    h.getChildren().addAll(l, descripcion);
    Button buscar = new Button();
    buscar.setText("Buscar");
    final Text buscado = new Text();
    buscar.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent t) {
        boolean enc = false;
        if (!descripcion.getText().isEmpty()) {
          for (int i = 0; i < cantidad; i++) {
            if (descripcion.getText().equals(articulos[i].getDescripcion())) {
              datos(articulos[i]);
              enc = true;
            }
          }
          if (!enc) {
            buscado.setFill(Color.BLUEVIOLET);
            buscado.setText("Producto no encontrado");
          }
        }else{
          buscado.setFill(Color.VIOLET);
          buscado.setText("No puedes dejar el campo vacío");
        }
      }
    });
    VBox v = new VBox(16);
    v.setAlignment(Pos.CENTER);
    v.setPadding(new Insets(16, 16, 16, 16));
    v.getChildren().addAll(h, buscar, buscado);
    StackPane sp = new StackPane();
    sp.getChildren().add(v);
    Scene s = new Scene(sp);
    bd.setScene(s);
    bd.setResizable(false);
    bd.show();
  }
  /**
   * Método que imprime una lista con los nombres de los artículos
   */
  public void mostrarNombre(){
    Stage mn = new Stage();
    mn.setTitle("Nombre de los productos");
    TableView<Producto> tv = new TableView();
    ObservableList<Producto> ol = FXCollections.observableArrayList(articulos);
    Scene s = new Scene(new Group());
    tv.setEditable(true);
    TableColumn cn = new TableColumn("Nombre");
    cn.setCellValueFactory(new PropertyValueFactory<>("nombre"));
    tv.setItems(ol);
    tv.getColumns().addAll(cn);
    VBox vb = new VBox(8);
    vb.setAlignment(Pos.CENTER);
    vb.setPadding(new Insets(16, 8, 8, 16));
    vb.getChildren().addAll(tv);
    ((Group) s.getRoot()).getChildren().addAll(vb);
    mn.setScene(s);
    mn.setResizable(false);
    mn.show();
  }
  /**
   * Método que imprime una lista con las claves y nombres de los artículos
   */
  public void mostrarClave(){
    Stage mc = new Stage();
    mc.setTitle("Clave de los productos");
    TableView<Producto> tv = new TableView();
    ObservableList<Producto> ol = FXCollections.observableArrayList(articulos);
    Scene s = new Scene(new Group());
    tv.setEditable(true);
    TableColumn cc = new TableColumn("Clave");
    cc.setCellValueFactory(new PropertyValueFactory<>("clave"));
    TableColumn cn = new TableColumn("Nombre");
    cn.setCellValueFactory(new PropertyValueFactory<>("nombre"));
    tv.setItems(ol);
    tv.getColumns().addAll(cc, cn);
    VBox vb = new VBox(8);
    vb.setAlignment(Pos.CENTER);
    vb.setPadding(new Insets(16, 8, 8, 16));
    vb.getChildren().addAll(tv);
    ((Group) s.getRoot()).getChildren().addAll(vb);
    mc.setScene(s);
    mc.setResizable(false);
    mc.show();
  }
  
  /**
   * Método que calcula la sumatoria de los precios unitarios de los artículos del arreglo
   */
  public void costo(){
    double sumatoria = 0;
    System.out.println("Clave\t Nombre\t Precio de compra");
    for (int i = 0; i < cantidad; i++) {
      System.out.println(articulos[i].getClave()+"\t"+articulos[i].getNombre()+"\t"
          +articulos[i].getPrecioCompra());
      sumatoria += articulos[i].getPrecioCompra();
    }
    System.out.println("El costo total del inventario es: "+sumatoria);
  }
  /**
   * @param args Parámetro que permitirá ejecutar la ventana
   */
  public static void main(String[] args) {
    launch(args);    //Se lanza la ventana
  }
  
}
