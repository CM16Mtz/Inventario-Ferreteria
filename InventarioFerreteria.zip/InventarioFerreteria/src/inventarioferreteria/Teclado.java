package inventarioferreteria;

import java.util.Scanner;

/**
 * @author Samsung
 * @version 1.0
 */
public class Teclado {

  private Scanner sc;    //Objeto 'Scanner' que permite al usuario ingresar datos

  /**
   * Inicializa nuestro objeto sc con la entrada estándar que es la lectura desde el teclado
   */
  public Teclado() {
    sc = new Scanner(System.in);
  }

  /**
   * Método que lee un entero ingresado
   */
  public int leerEntero() {
    int i = sc.nextInt();    //Lee el entero
    sc.nextLine();
    return i;    //Regresa el entero leído
  }

  /**
   * Este método lee un double
   */
  public double leerDouble() {
    double d = sc.nextDouble();    //Lee el double
    sc.nextLine();
    return d;    //Regresa el double leído
  }
  
  /**
   * Este método regresauna cadena
   */
  public String leerSiguienteCadena(){
    return sc.nextLine();    //Regresa la cadena ingresada
  }

}
