package inventarioferreteria;

import java.util.Scanner;

//@author Martinez Sosa Jatniel Jasdekj
//@version 0.1
public class Teclado {

  private Scanner sc;

  /* Inicializa nuestro objeto sc con la entrada estándar que es la lectura desde el teclado */
  public Teclado() {
    sc = new Scanner(System.in);
  }

  /* Este método lee un entero
   * @return regresa un valor de tipo entero
   */
  public int leerEntero() {
    return sc.nextInt();
  }

  /* Este método lee un double
    *  Return regresa un valor de tipo double
   */
  public double leerDouble() {
    return sc.nextDouble();
  }
  /**
   * Este método regresa una cadena
   * @return La cadena leída
   */
  public String leerCadena(){
    return sc.next();    
  }
  /**
   * Este método regresauna cadena
   * @return La cadena de la siguiente línea
   */
  public String leerSiguienteCadena(){
    return sc.nextLine();
  }

}
