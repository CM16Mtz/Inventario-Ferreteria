/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventarioferreteria;

/**
 * @author Samsung
 * @version 1.0
 */
public class InventarioFerreteria {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    /**
     * Método que mostrará un menú. El usuario debe ingresar un número de acuerdo a la operación
     * que quiera realizar en el programa
     */
    Menu m = new Menu();
    int o;
    do{
      m.menu();
      o = m.leerOpcion();
      m.realizarOperacion(o);
    }while (o != 10);
  }
  
}
