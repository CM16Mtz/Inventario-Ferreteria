package inventarioferreteria;

/**
 * @author Samsung
 * @version 1.0
 */
public class InventarioFerreteria {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    
    /**
     * Método que mostrará un menú. El usuario debe ingresar un número de acuerdo a la operación
     * que quiera realizar en el programa
     *//*
    Menu m = new Menu();
    int o;    //Atributo que representa el número de la operación a realizar
    do{
      m.menu();    //Se abre el menú
      o = m.leerOpcion();    //Se pide el número de la operación a realizar
      m.realizarOperacion(o);    //Se procede a ejecutar la operación
    }while (o != 12);    //Si la operación que seleccionó es la 10, se cierra el programa*/
  }
  
}
